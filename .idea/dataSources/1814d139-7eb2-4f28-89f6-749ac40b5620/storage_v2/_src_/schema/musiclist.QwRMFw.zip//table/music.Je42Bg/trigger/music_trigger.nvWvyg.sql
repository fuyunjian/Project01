create trigger music_trigger
  after UPDATE
  on music
  for each row
  begin
update listen set Mname = new.Mname where Mnumber = new.Mnumber;
end;

